﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using NUnit.Framework;
using OpenQA.Selenium;
using System.Threading.Tasks;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Support.UI;

namespace AbbyyLS.CAT.Function.Selenium.Tests
{
	/// <summary>
	/// Группа тестов для проверки колонки match в таргете при выдачах из cat-панели
	/// </summary>
	class CatPanelSubstitutionTest : BaseTest
	{

		/// <summary>
		/// Конструктор теста
		/// </summary>
		 
		 
		/// <param name="browserName">Название браузера</param>
		public CatPanelSubstitutionTest(string browserName)
			: base (browserName)
		{
			
		}

		// название проекта для проведения тестов
		protected string _projectNameMatchTest = "MatchTest" + "_" + DateTime.UtcNow.Ticks.ToString();

		// флаг создан ли проект (создается один раз перед всеми тестами)
		private bool _projectCreated; 
		
		/// <summary>
		/// Подготовка перед каждым тестом
		/// </summary>
		[SetUp]
		public void SetUp()
		{
			// Не выходить из браузера после теста
			quitDriverAfterTest = false;

			if (!_projectCreated)
			{
				GoToWorkspace();
				
				// создаем документ с нужным файлом, нужной ТМ, подкючаем МТ и глоссарий
				CreateProject(_projectNameMatchTest, TxtFileForMatchTest,
				true, TmxFileForMatchTest,
				Workspace_CreateProjectDialogHelper.SetGlossary.New, "",
				true, Workspace_CreateProjectDialogHelper.MT_TYPE.DefaultMT,
				false);

				Thread.Sleep(2000);

				// Открываем диалог выбора исполнителя
				OpenAssignDialog(_projectNameMatchTest);

				// Выбор в качестве исполнителя для первой задачи первого юзера
				SetResponsible(1, UserName, false);
				ResponsiblesDialog.ClickCloseBtn();

				// Открытие страницы проекта
				OpenProjectPage(_projectNameMatchTest);
				
				// Подтверждение назначения
				ProjectPage.ClickAllAcceptBtns();
				Thread.Sleep(1000);
				
				// Открываем документ
				OpenDocument();
				Thread.Sleep(1000);

				_projectCreated = true;
			}
			else
			{
				
				Thread.Sleep(1000);
			}
		}

		/// <summary>
		/// Для пяти сегментов подставляет значение из TM
		/// проверка1: в таргете появилось значение в колонке match - ресурс ТМ  
		/// проверка2: проверка, что число совпадает с числом из СAT-панели
		/// проверка3: проверка цветового выделения
		/// </summary>
		///  <param name="segmentNumber">номер сегмента таргет для подстановки из CAT</param>

		[Test]
		public void CheckMatchAfterTmSubstitutionSegmentNumber([Values(1, 2, 3, 4, 5)]int segmentNumber)
		{
			const int yellowUpperBound = 99;
			const int yellowLowerBound = 76;

			const string green = "green";
			const string yellow = "yellow";
			const string red = "red";

			const string catSubstitutionTmType = "TM";

			// номер строки CAT-панели, из которой выполнена подстановка
			int catSubstitutionLineNumber;

			//кликаем в таргет, чтобы заполнилась панель CAT
			EditorPage.ClickTargetCell(segmentNumber);

			//ищем в кат номер строки с подходящим термином из ТМ, подставляем в таргет
			catSubstitutionLineNumber = PasteFromCatReturnCatLineNumber(segmentNumber, EditorPageHelper.CAT_TYPE.TM);
			
			//проверка1: появилось значение в колонке match - ресурс ТМ  
			Assert.AreEqual(catSubstitutionTmType, EditorPage.GetTargetSubstitutionType(segmentNumber));

			//проверяем, сколько процентов в колонке match таргета
			int targetMatchPercent = EditorPage.GetTargetMatchPercent(segmentNumber);
			//проверка2: проверка, что число совпадает с числом из СAT-панели
			Assert.AreEqual(targetMatchPercent, CatPanel.GetCATTranslationProcentMatch(catSubstitutionLineNumber-1)); 
			
			//проверка3: проверка цветового выделения
			if (targetMatchPercent > yellowUpperBound)
				Assert.AreEqual( green, EditorPage.GetTargetMatchColor(segmentNumber));
			if (targetMatchPercent <= yellowUpperBound && targetMatchPercent >= yellowLowerBound)
				Assert.AreEqual(yellow, EditorPage.GetTargetMatchColor(segmentNumber));
			if (targetMatchPercent < yellowLowerBound)
				Assert.AreEqual(red, EditorPage.GetTargetMatchColor(segmentNumber));
			
		}

		/// <summary>
		/// Для одного сегмента подставляет значение из MT
		/// проверка1: в таргете появилось значение в колонке match - ресурс MT
		/// проверка2: проверка, что число совпадает с числом из СAT-панели
		/// </summary>
		[Test]
		public void CheckMatchAfterMtSubstitution()
		{
			// номер строки CAT-панели, из которой выполнена подстановка
			int catSubstitutionLineNumber;
			int segmentNumber = 1;
			const string catSubstitutionMtType = "MT";

			// кликаем в таргет, чтобы заполнилась панель CAT 
			EditorPage.ClickTargetCell(segmentNumber);
			
			//ищем в кат номер строки с подходящим термином из MT, подставляем в таргет
			catSubstitutionLineNumber = PasteFromCatReturnCatLineNumber(segmentNumber, EditorPageHelper.CAT_TYPE.MT);
			
			//проверка1: появилось значение в колонке match - ресурс MT  
			Assert.AreEqual(catSubstitutionMtType, EditorPage.GetTargetSubstitutionType(segmentNumber));
			
			//проверяем, сколько процентов в колонке match таргета
			int targetMatchPercent = EditorPage.GetTargetMatchPercent(segmentNumber);
			//проверка2: проверка, что число совпадает с числом из СAT-панели
			Assert.AreEqual(targetMatchPercent, CatPanel.GetCATTranslationProcentMatch(catSubstitutionLineNumber-1));
		}

		/// <summary>
		/// Для одного сегмента подставляет значение из MT
		/// проверка1: в таргете появилось значение в колонке match - ресурс MT
		/// Затем подставляет значение из TM
		/// проверка2: в таргете появилось значение в колонке match - ресурс TM
		/// </summary>
		[Test]
		public void CheckMatchAfterBothSubstitutions()
		{
			// идентификатор типа замены из cat-панели
			const string catSubstitutionTmType = "TM";
			const string catSubstitutionMtType = "MT";
			// номер строки CAT-панели, из которой выполнена подстановка
			int catSubstitutionLineNumber;
			int segmentNumber = 1;

			// кликаем в таргет, чтобы заполнилась панель CAT 
			EditorPage.ClickTargetCell(segmentNumber);
			
			//ищем в кат номер строки с подходящим термином из МТ, подставляем в таргет
			catSubstitutionLineNumber = PasteFromCatReturnCatLineNumber(segmentNumber, EditorPageHelper.CAT_TYPE.MT);
			
			//проверка1: появилось значение в колонке match - ресурс MT  
			Assert.AreEqual(catSubstitutionMtType, EditorPage.GetTargetSubstitutionType(segmentNumber));
			
			//проверяем, сколько процентов в колонке match таргета
			int targetMatchPercent = EditorPage.GetTargetMatchPercent(segmentNumber);
			//проверка2: проверка, что число совпадает с числом из СAT-панели
			Assert.AreEqual(targetMatchPercent, CatPanel.GetCATTranslationProcentMatch(catSubstitutionLineNumber - 1));

			//удаляем подставленный термин
			EditorPage.AddTextTarget(segmentNumber, "");

			//заполняем снова CATpanel
			EditorPage.ClickTargetCell(segmentNumber);

			//ищем в кат номер строки с подходящим термином из ТМ, подставляем в таргет
			catSubstitutionLineNumber = PasteFromCatReturnCatLineNumber(segmentNumber, EditorPageHelper.CAT_TYPE.TM);
			
			//проверка1: появилось значение в колонке match - ресурс ТМ  
			Assert.AreEqual(catSubstitutionTmType, EditorPage.GetTargetSubstitutionType(segmentNumber));
			//проверяем, сколько процентов в колонке match таргета
			targetMatchPercent = EditorPage.GetTargetMatchPercent(segmentNumber);
			//проверка2: проверка, что число совпадает с числом из СAT-панели
			Assert.AreEqual(targetMatchPercent, CatPanel.GetCATTranslationProcentMatch(catSubstitutionLineNumber - 1));
		}

		/// <summary>
		/// Для одного сегмента подставляет значение из TM
		/// В таргете дописали текст
		/// проверка: в таргете осталось значение в колонке match - ресурс TM
		/// </summary>
		[Test]
		public void CheckMatchAfterEditCell()
		{
			const string catSubstitutionType = "TM";
			// номер строки CAT-панели, из которой выполнена подстановка
			int catSubstitutionLineNumber;
			int segmentNumber = 1;

			// кликаем в таргет, чтобы заполнилась панель CAT 
			EditorPage.ClickTargetCell(segmentNumber);

			//ищем в кат номер строки с подходящим термином из TM, подставляем в таргет
			catSubstitutionLineNumber = PasteFromCatReturnCatLineNumber(segmentNumber, EditorPageHelper.CAT_TYPE.TM);

			//добавляем в таргет текст
			EditorPage.ClickTargetCell(segmentNumber);
			EditorPage.SendKeysTarget(segmentNumber, " hello ");

			//проверка1: значение в колонке match прежнее - ресурс ТМ  
			Assert.AreEqual(catSubstitutionType, EditorPage.GetTargetSubstitutionType(segmentNumber));
			//проверяем, сколько процентов в колонке match таргета
			int targetMatchPercent = EditorPage.GetTargetMatchPercent(segmentNumber);
			//проверка2: проверка, что число совпадает с числом из СAT-панели
			Assert.AreEqual(targetMatchPercent, CatPanel.GetCATTranslationProcentMatch(catSubstitutionLineNumber - 1));
		}
		
		/// <summary>
		/// Для одного сегмента подставляет значение из TM
		/// В таргете удалили текст и вставили новый
		/// проверка: в таргете осталось значение в колонке match - ресурс TM
		/// </summary>
		[Test]
		public void CheckMatchAfterDelete()
		{
			const string catSubstitutionType = "TM";
			// номер строки CAT-панели, из которой выполнена подстановка
			int catSubstitutionLineNumber;
			int segmentNumber = 1;

			// кликаем в таргет, чтобы заполнилась панель CAT
			EditorPage.ClickTargetCell(segmentNumber);

			//ищем в кат номер строки с подходящим термином из TM, подставляем в таргет
			catSubstitutionLineNumber = PasteFromCatReturnCatLineNumber(segmentNumber, EditorPageHelper.CAT_TYPE.TM);

			//удаляем текст, вставляем новый
			EditorPage.ClickTargetCell(segmentNumber);
			EditorPage.AddTextTarget(segmentNumber, "new text");

			//проверка1: значение в колонке match прежнее - ресурс ТМ  
			Assert.AreEqual(catSubstitutionType, EditorPage.GetTargetSubstitutionType(segmentNumber));
			//проверяем, сколько процентов в колонке match таргета
			int targetMatchPercent = EditorPage.GetTargetMatchPercent(segmentNumber);
			//проверка2: проверка, что число совпадает с числом из СAT-панели
			Assert.AreEqual(targetMatchPercent, CatPanel.GetCATTranslationProcentMatch(catSubstitutionLineNumber - 1));
		
		}



		/// <summary>
		/// Подстановка в непустой сегмент: для одного сегмента подставляет значение из TM, MT
		/// проверка: в таргете осталось значение в колонке match - ресурс TM/MT
		/// </summary>
		///  <param name="catType">тип подстановки из CAT</param>
		///  <param name="catSubstitutionType">двухбуквенное обозначение типа подстановки из CAT</param>
		[Test, Sequential]
		public void CheckTmMtMatchAfterAdd(
			[Values(EditorPageHelper.CAT_TYPE.TM, EditorPageHelper.CAT_TYPE.MT)] EditorPageHelper.CAT_TYPE catType,
			[Values("TM", "MT")] string catSubstitutionType)
		{
			// номер строки CAT-панели, из которой выполнена подстановка
			int catSubstitutionLineNumber;
			int segmentNumber = 1;

			// пишем текст
			EditorPage.ClickTargetCell(segmentNumber);
			EditorPage.SendKeysTarget(1, " hello ");

			//ищем в кат номер строки с подходящим термином из ТМ, подставляем в таргет
			catSubstitutionLineNumber = PasteFromCatReturnCatLineNumber(segmentNumber, catType);

			//проверка1: значение в колонке match прежнее - ресурс ТМ  
			Assert.AreEqual(catSubstitutionType, EditorPage.GetTargetSubstitutionType(segmentNumber));
			//проверяем, сколько процентов в колонке match таргета
			int targetMatchPercent = EditorPage.GetTargetMatchPercent(segmentNumber);
			//проверка2: проверка, что число совпадает с числом из СAT-панели
			Assert.AreEqual(targetMatchPercent, CatPanel.GetCATTranslationProcentMatch(catSubstitutionLineNumber - 1));
		
		}

		/// <summary>
		/// Для одного сегмента подставляет значение из глоссария
		/// проверка: в таргете исчезло значение в колонке match
		/// </summary>
		[Test]
		public void AfterGlossarySubstitutionCheckMatch()
		{
			const string catSubstitutionTbType = "";
			// номер строки CAT-панели, из которой выполнена подстановка
			int segmentNumber = 1;

			EditorPage.ClickTargetCell(segmentNumber);

			string sourceTerm = EditorPage.GetSourceText(segmentNumber);

			AddTermGlossary(sourceTerm, "термин глоссария");

			EditorPage.ClickTargetCell(segmentNumber);
			PasteFromCat(segmentNumber, EditorPageHelper.CAT_TYPE.TB);

			Assert.AreEqual(catSubstitutionTbType, EditorPage.GetTargetSubstitutionType(segmentNumber));

		}

		/// <summary>
		/// Добавляет сорс-таргет сегмента в глоссарий для теста
		/// </summary>
		///  <param name="sourceTerm">слово для внесения в словарь</param>
		///  <param name="targetTerm">перевод слова словаря</param>

		public void AddTermGlossary(string sourceTerm, string targetTerm)
		{
			// Нажать кнопку вызова формы для добавления термина
			EditorPage.ClickAddTermBtn();
			// Добавить сорс
			AddTermForm.TypeSourceTermText(sourceTerm);
			// Добавить термин в таргет
			AddTermForm.TypeTargetTermText(targetTerm);
			// Нажать сохранить
			AddTermForm.ClickAddBtn();
			
			Thread.Sleep(2000);
			// Термин сохранен, нажать ок
			AddTermForm.ClickTermSaved();
		}

		
	}
}

